# DecisionTreeAssignment.py
# Ethan Dall
# 10/18/2020
# Machine Learning

# Imports
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from pydotplus import graph_from_dot_data
from sklearn.tree import export_graphviz

# This method determines which regions are highlighted within the graphs
def plot_decision_regions(X, y, classifier, test_idx=None, resolution=0.02):

    # setup marker generator and color map
    markers = ('s', 'x', 'o', '^', 'v')
    colors = ('red', 'blue', 'lightgreen', 'gray', 'cyan')
    cmap = ListedColormap(colors[:len(np.unique(y))])

    # plot the decision surface
    x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, resolution),
                           np.arange(x2_min, x2_max, resolution))
    Z = classifier.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
    Z = Z.reshape(xx1.shape)
    plt.contourf(xx1, xx2, Z, alpha=0.3, cmap=cmap)
    plt.xlim(xx1.min(), xx1.max())
    plt.ylim(xx2.min(), xx2.max())

    for idx, cl in enumerate(np.unique(y)):
        plt.scatter(x=X[y == cl, 0], 
                    y=X[y == cl, 1],
                    alpha=0.8, 
                    c=colors[idx],
                    marker=markers[idx], 
                    label=cl, 
                    edgecolor='black')

    # highlight test samples
    if test_idx:
        # plot all samples
        X_test, y_test = X[test_idx, :], y[test_idx]

        plt.scatter(X_test[:, 0],
                    X_test[:, 1],
                    c='',
                    edgecolor='black',
                    alpha=1.0,
                    linewidth=1,
                    marker='o',
                    s=100, 
                    label='test set')
        
# Main
# Define Data
df = pd.read_csv("MBA_Data.csv", header="infer")
length = len(df)
# X is the Age group and whether they have Astigmatism or not, and Y is the Tear-Prod-Rate
X = df.iloc[0:int(length), [0,2]].values
y = df.iloc[0:int(length), 3].values

# Shows the size and train result for X and Y arrays
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

# Build and Print the DecisionTree
tree = DecisionTreeClassifier(criterion='gini', max_depth=4, random_state=1)
tree.fit(X_train, y_train)

# Calculate the Accuracy of the Data under the 'gini' criteria
print('Accuracy Score on the test data [Gini]: ', accuracy_score(y_true=y_test, y_pred=tree.predict(X_test)))

# Create a Tree plot
dot_data = export_graphviz(tree,filled=True,rounded=True,
                           class_names=['GMAT', 
                                        'GPA',
                                        'Score'],
                           feature_names=['No', 
                                          'Yes'],
                           out_file=None)

graph = graph_from_dot_data(dot_data) 
graph.write_png('DataTree.png')

# Calculate the Accuracy of the Data under the 'entropy' criteria
tree = DecisionTreeClassifier(criterion = 'entropy')
tree.fit(X_train, y_train)
print('Accuracy Score on the test data [Entropy]: ', accuracy_score(y_true=y_test, y_pred=tree.predict(X_test)))

# Prediction of Age
XAge = df.iloc[0:int(length), [0]].values
X_train, X_test, y_train, y_test = train_test_split(XAge, y, test_size=0.3)
# Reshape for 2D Array
X_test = X_test.reshape(-1,2)
print("Age Prediction: ", tree.predict(X_test))

# Prediction of Prescription
XPresc = df.iloc[0:int(length), [1]].values
X_train, X_test, y_train, y_test = train_test_split(XPresc, y, test_size=0.3)
# Reshape for 2D Array
X_test = X_test.reshape(-1,2)
print("Prescription Prediction: ", tree.predict(X_test))

# Prediction of Astigmatism
XAst = df.iloc[0:int(length), [0]].values
X_train, X_test, y_train, y_test = train_test_split(XAst, y, test_size=0.3)
# Reshape for 2D Array
X_test = X_test.reshape(-1,2)
print("Astigmatism Prediction: ", tree.predict(X_test))

# Prediction of Tear-Prod-Rate
XTPR = df.iloc[0:int(length), [0]].values
X_train, X_test, y_train, y_test = train_test_split(XTPR, y, test_size=0.3)
# Reshape for 2D Array
X_test = X_test.reshape(-1,2)
print("Tear-Prod-Rate Prediction: ", tree.predict(X_test))